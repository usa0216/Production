import tkinter as tk
from PIL import Image, ImageTk
import random
cnt = 0


#じゃんけんの演算
def zyanken():
    global result1
    global result2
    global cnt
    cnt +=1
    if cnt > 1:
        result1.place_forget()
        result2.place_forget()

    kobusi = ["グー","チョキ","パー"]
    play = option.get()
    cpu = play
    while play == cpu:
        cpu = random.choice(kobusi)
        result1 = "あなた：" + play + "、CPU：" + cpu
        if play != cpu:
            if play == "グー" and cpu == "パー":
                result2 = "結果：あなたの負け..."
                break
            elif play == "チョキ" and cpu == "グー":
                result2 = "結果：あなたの負け..."
                break
            elif play == "パー" and cpu == "チョキ":
                result2 = "結果：あなたの負け..."
                break
            else :
                result2 = "結果：あなたの勝ち！"
                break
        else:
            result2 = "結果：あいこ！もういっかい！"
            break

    result1 = tk.Label(root, text=result1)
    result2 = tk.Label(root, text=result2)

    result1.place(x=380,y=500)
    result2.place(x=380,y=550)


#メインウィンドウ作成
root = tk.Tk()
root.title("じゃんけんゲーム")
root.geometry("900x600+325+100")
root.resizable(False,False)
#root.configure(bg="blue")


#キャンバス作成
canvas1 = tk.Canvas(root, width=900,height=600,bg="lightblue")
canvas1.place(x=0,y=0)

#画像の読込
img1 =Image.open("gu.png")
img1 = img1.resize((200, 200))
kobushi1 = ImageTk.PhotoImage(img1)

img2 =Image.open("choki.png")
img2 = img2.resize((200, 200))
kobushi2 = ImageTk.PhotoImage(img2)

img3 =Image.open("pa.png")
img3 = img3.resize((200, 200))
kobushi3 = ImageTk.PhotoImage(img3)


#画像をキャンバスに表示
canvas1.create_image(180, 200, image=kobushi1)
canvas1.create_image(430, 200, image=kobushi2)
canvas1.create_image(680, 200, image=kobushi3)


#選択したオプションを格納するための変数
option = tk.StringVar(value="グー")

#ラジオボタン
rb1 = tk.Radiobutton(root, text="グー", variable=option, value="グー")
rb2 = tk.Radiobutton(root, text="チョキ", variable=option, value="チョキ")
rb3 = tk.Radiobutton(root, text="パー", variable=option, value="パー")

rb1.place(x=150,y=350)
rb2.place(x=400,y=350)
rb3.place(x=650,y=350)

#サブボタン
sb = tk.Button(root, text="じゃんけん、、、？", command=zyanken)
sb.place(x=400,y=400)



#ウィンドウを表示
root.mainloop()