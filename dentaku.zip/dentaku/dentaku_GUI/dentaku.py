import tkinter as tk
import tkinter.ttk as ttk

kekka = "0" #電卓上に表示する入力中の内容or計算結果（3桁区切りなし）
hyouzi = "0"#電卓上に表示する入力中の内容or計算結果(3桁区切り)
katei1 = "" #電卓上に表示する過程
katei2 = "" #計算に使用する過程
en = ""     #直前に入力した一部記号を判別（「1」なら演算子、「2」なら「=」）
en2 = 0     #「=」を押すまでに演算子を打ったか判別
ten = 0     #直前に小数点を入力したか判別（「0」なら未入力、「1」なら入力済）


#ウインドウ作成
root = tk.Tk()
root.title("電卓ソフト")
root.geometry("400x550+1100+200")
root.resizable(False, False) #ウィンドウサイズは固定


#初期表示
label1 = tk.Label(root, text=kekka, bg="black", fg="white", font=("Arial", 16), height=4, width=31, anchor=tk.E)#最後のアンカーで配置を右寄りに
label2 = tk.Label(root, text=katei1, bg="black", fg="white", font=("Arial", 11), height=1, width=20, anchor=tk.E)

label1.place(x=10,y=125)
label2.place(x=201,y=90)




def henkan(): #電卓上に表示される演算子を計算可能な演算子に変換
    global nyu
    global en
    global katei2
    global kekka

    en = 1 #演算子が「+」、「-」、「*」、「/」の場合
    if nyu == "×" or nyu == "÷":
        if nyu == "×":
            nyu = "*"
        else:
            nyu = "/"
    katei2 = str(kekka) + nyu
        


def kanma(suu): #入力中の内容、または計算結果を3桁区切り
    return "{:,}".format(suu)


def sfhandan(): #計算結果が整数か浮動小数点か判断
    global kekka
    global hyouzi

    handan = float(kekka)

    if handan.is_integer():
      hyouzi = kanma(int(handan))
    else:
        hyouzi = kanma(float(handan))




def keisan(event): #ボタンを押した際に呼び出され、計算や電卓上への表示を行う
    global nyu
    global kekka
    global hyouzi
    global katei1
    global katei2
    global label1
    global label2
    global en
    global en2
    global ten

    nyu = event.widget.cget("text") #ボタンに表示されている内容を変数に代入

    if nyu == "=":
        ten = 0
        if en == 2:
            pass
        else:
            katei1 = katei1 + " " + str(kekka)
            katei2 = katei2 + str(kekka)
            en2 = 0
            if katei1[-1] == "+" or katei1[-1] == "-" or katei1[-1] == "×" or katei1[-1] == "÷" or katei1[-1] == ".":
                katei2 = katei2[:-1]#もし演算子の後にイコールが入力された場合は、演算子抜きの値を代入
                kekka = eval(katei2)#文字列を数値に変換して計算する
                sfhandan()
                en = 2 #演算子が「＝」の場合
            else:
                kekka = eval(katei2)#文字列を数値に変換して計算する
                sfhandan()
                en = 2


    elif nyu == "+" or nyu == "-" or nyu == "×" or nyu == "÷":
        ten = 0
        if en == 1 or en2 == 1:
            pass
        elif katei1 == "":
            katei1 = kekka + " " + nyu
            henkan()
        else:
            if en == 2:
                katei1 = str(kekka) + " " + nyu
                henkan()
            else:
                katei1 = katei1 + " " + nyu
                henkan()

    elif nyu == "Del":
        if en == 1:
            pass
        elif en == 2:
            kekka = "0"
            hyouzi = "0"
            katei1 = ""
            katei2 = ""
            en = ""
            en2 = 0
            ten = 0
        else:
            kekka = kekka[:-1]
            if kekka == "":
                hyouzi = "0"
            else:
                hyouzi = kanma(float(kekka))

    elif nyu == "CE":
        kekka = "0"
        hyouzi = "0"
        katei1 = ""
        katei2 = ""
        en = ""
        en2 = 0
        ten = 0

    else: #0~9、00、000、.を入力した場合
        mozisuu = len(str(kekka))#表示中の文字数をカウント
        if mozisuu >= 10 and en == "":#13桁以上の文字を入力させない
            pass
        elif kekka == "0":
            if nyu == "00" or nyu == "000":
                kekka = "0"
                hyouzi = "0"
                katei2 = ""
            elif nyu == ".":
                kekka = "0."
                hyouzi = "0."
                ten = 1
            else:
                kekka = nyu
                hyouzi = nyu
        else:
            if en == "":
                if nyu == ".":
                    if ten == 1:
                        pass
                    else:
                        ten = 1
                        kekka = kekka + "."
                        hyouzi = hyouzi + "."
                else:
                    kekka = kekka + nyu
                    if ten == 1 or nyu == "00" or nyu == "000":
                        hyouzi = hyouzi + nyu
                        #ten = 0
                    else:
                        sfhandan()
            else:
                if en == 2:
                    if nyu == ".":
                        kekka = "0."
                        hyouzi = "0."
                        ten = 1
                        katei1 = ""
                        katei2 = ""
                        en = ""
                    elif nyu == "00" or nyu == "000":
                        kekka = "0"
                        hyouzi = "0"
                        katei1 = ""
                        katei2 = ""
                        en = ""
                    else:
                        kekka = nyu
                        hyouzi = nyu
                        katei1 = ""
                        katei2 = ""
                        en = ""
                elif en == 1:
                    if nyu == ".":
                        kekka = "0."
                        hyouzi = "0."
                        ten = 1
                        en = ""
                    else: 
                        if nyu == "0" or nyu == "00" or nyu == "000":
                            kekka = "1"
                            hyouzi = "0"
                            en2 = 1
                        else:                       
                            kekka = nyu
                            hyouzi = nyu
                            en = ""
                            en2 = 1

    label1.place_forget()
    label2.place_forget()

    #計算中の内容や計算結果を表示
    label1 = tk.Label(root, text=hyouzi, bg="black", fg="white", font=("Arial", 16), height=4, width=31, anchor=tk.E)#最後のアンカーは配置を右寄りにしてるだけ
    label2 = tk.Label(root, text=katei1, bg="black", fg="white", font=("Arial", 11), height=1, width=20, anchor=tk.E)

    label1.place(x=10,y=125)
    label2.place(x=201,y=90)


#ボタン作成
button1 = tk.Button(root, text="1", bg="black", fg="white", width=10, height=3)
button2 = tk.Button(root, text="2", bg="black", fg="white", width=10, height=3)
button3 = tk.Button(root, text="3", bg="black", fg="white", width=10, height=3)
button4 = tk.Button(root, text="4", bg="black", fg="white", width=10, height=3)
button5 = tk.Button(root, text="5", bg="black", fg="white", width=10, height=3)
button6 = tk.Button(root, text="6", bg="black", fg="white", width=10, height=3)
button7 = tk.Button(root, text="7", bg="black", fg="white", width=10, height=3)
button8 = tk.Button(root, text="8", bg="black", fg="white", width=10, height=3)
button9 = tk.Button(root, text="9", bg="black", fg="white", width=10, height=3)
button10 = tk.Button(root, text="0", bg="black", fg="white", width=10, height=3)
button11 = tk.Button(root, text="+", bg="black", fg="white", width=10, height=3)
button12 = tk.Button(root, text="-", bg="black", fg="white", width=10, height=3)
button13 = tk.Button(root, text="×", bg="black", fg="white", width=10, height=3)
button14 = tk.Button(root, text="÷", bg="black", fg="white", width=10, height=3)
button15 = tk.Button(root, text="=", bg="black", fg="white", width=7, height=14)
button16 = tk.Button(root, text=".", bg="black", fg="white", width=10, height=3)
button17 = tk.Button(root, text="000", bg="black", fg="white", width=10, height=3)
button18 = tk.Button(root, text="00", bg="black", fg="white", width=10, height=3)
button19 = tk.Button(root, text="CE", bg="black", fg="white", width=16, height=3)
button20 = tk.Button(root, text="Del", bg="black", fg="white", width=25, height=3)

#ボタン配置
button1.place(x=10,y=250)
button2.place(x=90,y=250)
button3.place(x=170,y=250)
button4.place(x=10,y=305)
button5.place(x=90,y=305)
button6.place(x=170,y=305)
button7.place(x=10,y=360)
button8.place(x=90,y=360)
button9.place(x=170,y=360)
button10.place(x=90,y=415)
button11.place(x=250,y=250)
button12.place(x=250,y=305)
button13.place(x=250,y=360)
button14.place(x=250,y=415)
button15.place(x=330,y=250)
button16.place(x=10,y=471)
button17.place(x=170,y=415)
button18.place(x=10,y=415)
button19.place(x=90,y=471)
button20.place(x=204,y=471)

#ボタンクリック時のイベント設定
button1.bind("<Button-1>", keisan)
button2.bind("<Button-1>", keisan)
button3.bind("<Button-1>", keisan)
button4.bind("<Button-1>", keisan)
button5.bind("<Button-1>", keisan)
button6.bind("<Button-1>", keisan)
button7.bind("<Button-1>", keisan)
button8.bind("<Button-1>", keisan)
button9.bind("<Button-1>", keisan)
button10.bind("<Button-1>", keisan)
button11.bind("<Button-1>", keisan)
button12.bind("<Button-1>", keisan)
button13.bind("<Button-1>", keisan)
button14.bind("<Button-1>", keisan)
button15.bind("<Button-1>", keisan)
button16.bind("<Button-1>", keisan)
button17.bind("<Button-1>", keisan)
button18.bind("<Button-1>", keisan)
button19.bind("<Button-1>", keisan)
button20.bind("<Button-1>", keisan)


root.mainloop()

            